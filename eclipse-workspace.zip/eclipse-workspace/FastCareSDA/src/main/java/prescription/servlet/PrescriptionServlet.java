package prescription.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import prescription.dao.PrescriptionDao;
import prescription.bean.PrescriptionBean;


/**
 * Servlet implementation class PrescriptionServlet
 */
@WebServlet("/PrescriptionServlet")
public class PrescriptionServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    private PrescriptionDao PresDao;

    public void init() {
        PresDao = new PrescriptionDao();
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse   response) throws ServletException, IOException {
        doPost(request, response);
}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String doctorID = request.getParameter("doctorID");
        String patientID = request.getParameter("patientID");
        String details = request.getParameter("details");
        String prescriptionID = "random";
        
        
        PrescriptionBean User = new PrescriptionBean();
        User.setDetails(details);
        User.setDoctorID(doctorID);
        User.setPatientID(patientID);
        User.setPrescriptionID(prescriptionID);
        
        
       
        try {
            PresDao.uploadPrescription(User);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        response.sendRedirect("DoctorUploadPrescription.jsp");
    }
}
