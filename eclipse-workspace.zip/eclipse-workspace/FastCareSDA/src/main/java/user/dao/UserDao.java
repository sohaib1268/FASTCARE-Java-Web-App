package user.dao;

import doctor.bean.DoctorBean;
import doctor.dao.DoctorDao;
import lab.bean.LabBean;
import lab.dao.LabDao;
import patient.bean.PatientBean;
import patient.dao.PatientDao;
import pharmacy.bean.PharmacyBean;
import pharmacy.dao.PharmacyDao;
import user.bean.User;

public class UserDao {
	
	public UserDao createUserDao(User newUser)
	{
		if(newUser.getID() != null)
		{
			if(newUser.getID().contains("P-"))
			{
				PatientDao User = new PatientDao();
				return User;
			}
			
			if(newUser.getID().contains("PH-"))
			{
				PharmacyDao User = new PharmacyDao();
				return User;
			}
			
			if(newUser.getID().contains("D-"))
			{
				DoctorDao User = new DoctorDao();
				return User;
			}
			
			if(newUser.getID().contains("L-"))
			{
				LabDao User = new LabDao();
				return User;
			}
		}
		
		return null;
	}
	
	
	public boolean validateUser(User CurrentPatient) throws ClassNotFoundException
	{
		return false;	
	}
}
