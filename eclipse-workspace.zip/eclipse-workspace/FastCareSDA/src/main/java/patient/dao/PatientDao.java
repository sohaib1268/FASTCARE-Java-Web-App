package patient.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import patient.bean.PatientBean;



public class PatientDao {

    public int registerPatient(PatientBean User) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "INSERT INTO Patient" +
            "  (name_, patientID, password_, _Area,_Address,_City, emailAddress) VALUES  " +
            " (?, ?, ?, ?, ?,?,?);";

        int result = 0;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/FastCare?useSSL=false", "root", "123456");

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
        	
        	preparedStatement.setString(1, User.getUsername());
            preparedStatement.setString(2, User.getID());
            preparedStatement.setString(3, User.getPasscode());
            preparedStatement.setString(4, User.getArea());
            preparedStatement.setString(5, User.getAddress());
            preparedStatement.setString(6, User.getCity());
            preparedStatement.setString(7, User.getEmailAddress());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return result;
    }
    

    public boolean validateUser(PatientBean CurrentPatient) throws ClassNotFoundException {
        boolean status = false;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/FastCare?useSSL=false", "root", "123456");

            PreparedStatement preparedStatement = connection
            .prepareStatement("select * from Patient where patientID = ? and password_ = ? ")) {
            preparedStatement.setString(1, CurrentPatient.getID());
            preparedStatement.setString(2, CurrentPatient.getPasscode());
           
            PreparedStatement S1 = connection.prepareStatement("select name_ from Patient where patientID = ? and password_ = ? ");
			S1.setString(1, CurrentPatient.getID());
			S1.setString(2, CurrentPatient.getPasscode());
			ResultSet forName_ = S1.executeQuery();		
			if(forName_.next())
			{
				CurrentPatient.setUsername(forName_.getString(1));  
			}
			
			PreparedStatement S2 = connection.prepareStatement("select _Area from Patient where patientID = ? and password_ = ? ");
			S2.setString(1, CurrentPatient.getID());
			S2.setString(2, CurrentPatient.getPasscode());
			ResultSet forArea_ = S2.executeQuery();		
			if(forArea_.next())
			{
				CurrentPatient.setArea(forArea_.getString(1));  
			}
			
			
			PreparedStatement S3 = connection.prepareStatement("select _Address from Patient where patientID = ? and password_ = ? ");
			S3.setString(1, CurrentPatient.getID());
			S3.setString(2, CurrentPatient.getPasscode());
			ResultSet forAddress_ = S3.executeQuery();		
			if(forAddress_.next())
			{
				CurrentPatient.setAddress(forAddress_.getString(1));  
			}
			
			
			PreparedStatement S4 = connection.prepareStatement("select _City from Patient where patientID = ? and password_ = ? ");
			S4.setString(1, CurrentPatient.getID());
			S4.setString(2, CurrentPatient.getPasscode());
			ResultSet forCity_ = S4.executeQuery();		
			if(forCity_.next())
			{
				CurrentPatient.setCity(forCity_.getString(1));  
			}
			
			PreparedStatement S5 = connection.prepareStatement("select emailAddress from Patient where patientID = ? and password_ = ? ");
			S5.setString(1, CurrentPatient.getID());
			S5.setString(2, CurrentPatient.getPasscode());
			ResultSet forEmail_ = S5.executeQuery();		
			if(forEmail_.next())
			{
				CurrentPatient.setEmailAddress(forEmail_.getString(1));  
			}
			
			
			
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            status = rs.next();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return status;
    }
    
    
    

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}