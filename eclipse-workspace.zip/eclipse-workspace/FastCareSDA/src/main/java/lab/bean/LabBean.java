package lab.bean;
import java.io.Serializable;


public class LabBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
    private String labID;
    private String name;
    private String passcode;
    private String lablocation;
    private String emailAddress;
	
    public String getLabID() {
		return labID;
	}
	public void setLabID(String labID) {
		this.labID = labID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPasscode() {
		return passcode;
	}
	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}
	public String getLablocation() {
		return lablocation;
	}
	public void setLablocation(String lablocation) {
		this.lablocation = lablocation;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
}
