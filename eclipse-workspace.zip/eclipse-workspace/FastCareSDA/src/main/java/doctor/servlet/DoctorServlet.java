package doctor.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import doctor.dao.DoctorDao;
import doctor.bean.DoctorBean;

/**
 * Servlet implementation class DoctorServlet
 */
@WebServlet("/DoctorServlet")
public class DoctorServlet extends HttpServlet {
	   
		 /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private DoctorDao DDao;

	    public void init() {
	        DDao = new DoctorDao();
	    }
	    
	    protected void service(HttpServletRequest request, HttpServletResponse   response) throws ServletException, IOException {
	        doPost(request, response);
	}
	    
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {

	        String ID = request.getParameter("ID");
	        String username = request.getParameter("username");
	        String passcode = request.getParameter("passcode");
	        String City = request.getParameter("City");
	        String Area = request.getParameter("Area");
	        String Address = request.getParameter("Address");
	        String emailAddress = request.getParameter("emailAddress");
	        
	        DoctorBean User = new DoctorBean();
	        User.setID(ID);
	        User.setUsername(username);
	        User.setPasscode(passcode);
	        User.setArea(Area);
	        User.setCity(City);
	        User.setAddress(Address);
	        User.setEmailAddress(emailAddress);
	        
	       
	        try {
	            DDao.registerDoctor(User);
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }

	        response.sendRedirect("doctordetails.jsp");
	    }

}
