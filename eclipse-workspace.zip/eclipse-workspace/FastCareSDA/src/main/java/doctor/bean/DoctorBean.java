package doctor.bean;
import java.io.Serializable;
import user.bean.*;

public class DoctorBean extends User implements Serializable{
	    /**
	     * 
	     */
		private static final long serialVersionUID = 1L;
	    private String ID;
	    private String username;
	    private String passcode;
	    private String Area;
	    private String Address;
	    private String City;
	    private String emailAddress;
	    
	    @Override
		public String getID() {
			return ID;
		}
	    public String getArea() {
			return Area;
		}
		public void setArea(String area) {
			Area = area;
		}
		public String getAddress() {
			return Address;
		}
		public void setAddress(String address) {
			Address = address;
		}
		public String getCity() {
			return City;
		}
		public void setCity(String city) {
			City = city;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		@Override
		public void setID(String iD) {
			ID = iD;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		@Override
		public String getPasscode() {
			return passcode;
		}
		@Override
		public void setPasscode(String password) {
			this.passcode = password;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getEmailAddress() {
			return emailAddress;
		}
		public void setEmailAddress(String emailAddress) {
			this.emailAddress = emailAddress;
		}
}

