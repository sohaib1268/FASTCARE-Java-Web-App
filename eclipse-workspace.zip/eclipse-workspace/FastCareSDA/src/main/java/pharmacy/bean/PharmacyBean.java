package pharmacy.bean;

import java.io.Serializable;

public class PharmacyBean implements Serializable{
	/**
     * 
     */
	private static final long serialVersionUID = 1L;
    private String pharmacyID;
    private String pharmacyName;
    private String passcode;
    private String pharmacylocation;
    private String emailAddress;
    private String timings;
	
    public String getPharmacyID() {
		return pharmacyID;
	}
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
	public void setPharmacyID(String pharmacyID) {
		this.pharmacyID = pharmacyID;
	}
	public String getPharmacyName() {
		return pharmacyName;
	}
	public void setPharmacyName(String pharmacyName) {
		this.pharmacyName = pharmacyName;
	}
	public String getPasscode() {
		return passcode;
	}
	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}
	public String getPharmacylocation() {
		return pharmacylocation;
	}
	public void setPharmacylocation(String pharmacylocation) {
		this.pharmacylocation = pharmacylocation;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
	
 
}
