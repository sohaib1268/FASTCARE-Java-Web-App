package login.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import patient.bean.PatientBean;
import patient.dao.PatientDao;


@WebServlet("/LoginPatient")
public class LoginPatient extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    protected void service(HttpServletRequest request, HttpServletResponse   response) throws ServletException, IOException {
        doPost(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

    	String ID = request.getParameter("ID");
        String password = request.getParameter("password");
        PatientBean tmpUser = new PatientBean();
	    tmpUser.setID(ID);
	    tmpUser.setPasscode(password);
        PatientDao tmpDao = new PatientDao();
	        
	        
        try {
            if (tmpDao.validateUser(tmpUser)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
	            		
	    	//	request.setAttribute("Patient", tmpUser);
	    	//	request.getRequestDispatcher("SuccessPatient.jsp").forward(request, response);
	    		request.setAttribute("ID", tmpUser.getID());
	    		request.setAttribute("Name", tmpUser.getUsername());
	    		request.getRequestDispatcher("SuccessPatient.jsp").forward(request, response);
	    		response.sendRedirect("SuccessPatient.jsp");
            	
            } else {
                //HttpSession session = request.getSession();
                //session.setAttribute("user", username);
                response.sendRedirect("PatientLogin.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}