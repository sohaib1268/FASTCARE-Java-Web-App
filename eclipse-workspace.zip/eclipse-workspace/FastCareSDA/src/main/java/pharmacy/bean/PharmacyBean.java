package pharmacy.bean;

import java.io.Serializable;



public class PharmacyBean implements Serializable{
	/**
     * 
     */
	private static final long serialVersionUID = 1L;
    private String pharmacyID;
    private String pharmacyName;
    private String passcode;
    private String Area;
    private String Address;
    private String City;
    
    public String getArea() {
		return Area;
	}
	public void setArea(String area) {
		Area = area;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getPharmacyID() {
		return pharmacyID;
	}
	private String emailAddress;
    private String timings;
	
    public String getID() {
		return pharmacyID;
	}

    public void setID(String iD)
    {
    	pharmacyID = iD;
    }
    
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
	public void setPharmacyID(String pharmacyID) {
		this.pharmacyID = pharmacyID;
	}
	public String getPharmacyName() {
		return pharmacyName;
	}
	public void setPharmacyName(String pharmacyName) {
		this.pharmacyName = pharmacyName;
	}
	
	public String getPasscode() {
		return passcode;
	}
	
	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}

	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
	
 
}
