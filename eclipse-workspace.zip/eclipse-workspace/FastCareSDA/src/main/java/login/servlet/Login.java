package login.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import user.bean.*;
import user.dao.UserDao;

@WebServlet("/Login")
public class Login extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    protected void service(HttpServletRequest request, HttpServletResponse   response) throws ServletException, IOException {
        doPost(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

    	String ID = request.getParameter("ID");
        String password = request.getParameter("password");
        User tmpUser = new User();
        User currentUser = tmpUser.createUser(ID);
        
        if(currentUser != null)
        {
	        currentUser.setID(ID);
	        currentUser.setPasscode(password);
        }
        final UserDao tmpDao = new UserDao();
        UserDao UDao = new UserDao();
	        
        if(currentUser != null)
        UDao = tmpDao.createUserDao(currentUser);
	        
        try {
        	if (UDao != null)
            if (UDao.validateUser(currentUser)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
            	
            	if(ID != null)
            	{
	            	if(currentUser.getID().contains("P-"))
	            	{
	            		response.sendRedirect("SuccessPatient.jsp");
	            	}
	            	if(currentUser.getID().contains("PH-"))
	            	{
	            		response.sendRedirect("SuccessPharmacy.jsp");
	            	}
	            	if(currentUser.getID().contains("D-"))
	            	{
	            		response.sendRedirect("SuccessDoctor.jsp");
	            	}
	            	if(currentUser.getID().contains("L-"))
	            	{
	            		response.sendRedirect("SuccessLab.jsp");
	            	}
            	}
            } else {
                //HttpSession session = request.getSession();
                //session.setAttribute("user", username);
                response.sendRedirect("UserLogin.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}