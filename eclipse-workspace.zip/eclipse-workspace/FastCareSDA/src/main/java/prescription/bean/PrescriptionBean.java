package prescription.bean;
import java.io.Serializable;

public class PrescriptionBean implements Serializable {
		/**
	 * 
	 */
		private static final long serialVersionUID = 1L;
		String doctorID;
		String patientID;
		String details;
		String prescriptionID;
		
		public String getDoctorID() {
			return doctorID;
		}
		public void setDoctorID(String doctorID) {
			this.doctorID = doctorID;
		}
		public String getPatientID() {
			return patientID;
		}
		public void setPatientID(String patientID) {
			this.patientID = patientID;
		}
		public String getDetails() {
			return details;
		}
		public void setDetails(String details) {
			this.details = details;
		}
		public String getPrescriptionID() {
			return prescriptionID;
		}
		public void setPrescriptionID(String prescriptionID) {
			this.prescriptionID = prescriptionID;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		
		
}
