package lab.bean;
import java.io.Serializable;
import user.bean.*;


public class LabBean extends User implements Serializable {
	
	private static final long serialVersionUID = 1L;
    private String labID;
    private String name;
    private String passcode;
    private String Area;
    private String Address;
    private String City;
    
    public String getLabID() {
		return labID;
	}

	public void setLabID(String labID) {
		this.labID = labID;
	}

	public String getArea() {
		return Area;
	}

	public void setArea(String area) {
		Area = area;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}
	private String emailAddress;
	
    @Override
    public String getID() {
		return labID;
	}
    
    @Override
	public void setID(String labID) {
		this.labID = labID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String getPasscode() {
		return passcode;
	}
	
	@Override
	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}
	
	public String getLablocation() {
		return lablocation;
	}
	public void setLablocation(String lablocation) {
		this.lablocation = lablocation;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
}
