package user.bean;
import doctor.bean.*;
import patient.bean.*;
import lab.bean.*;
import pharmacy.bean.*;


public class User {
	private String ID;
	private String passcode;
	
	
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getPasscode() {
		return passcode;
	}

	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}

	public User createUser(String id)
	{
		
		if(id != null)
		{
			if(id.contains("P-"))
			{
				PatientBean User = new PatientBean();
				return User;
			}
			
			if(id.contains("PH-"))
			{
				PharmacyBean User = new PharmacyBean();
				return User;
			}
			
			if(id.contains("D-"))
			{
				DoctorBean User = new DoctorBean();
				return User;
			}
			
			if(id.contains("L-"))
			{
				LabBean User = new LabBean();
				return User;
			}
		}
		
		if(id == null)
		{
			PatientBean User = new PatientBean();
			return User;
		}
		
		return null;
	}
}
